﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Rac : Empleado
    {
        public enum EGrupo { CALL_IN, CALL_OUT, RRSS }

        private static float valorHora = 875.90f;
        private readonly EGrupo grupo;

        public EGrupo Grupo => grupo;

        public static float ValorHora
        {
            get => valorHora;
            set
            {
                if (value > 0)
                {
                    valorHora = value;
                }
            }
        }


        public Rac(string legajo, string nombre, TimeSpan horaIngreso, EGrupo grupo = EGrupo.CALL_IN)
            : base(nombre, legajo, horaIngreso)
        {
            this.grupo = grupo;
        }


        public float CalcularBono()
        {
            return grupo switch
            {
                EGrupo.CALL_OUT => 0.1f,
                EGrupo.RRSS => 0.2f,
                _ => 0f,
            };
        }


        public float Facturar()
        {
            var bono = CalcularBono();
            return (float)base.Facturar() * ValorHora * (1 + bono);
        }


        public override string EmitirFactura()
        {
            return $"Factura de: {this}\nImporte a facturar: {Facturar()}";
        }


        public override string ToString()
        {
            return $"{GetType().Name} - {Grupo} - {Legajo} - {Nombre}";
        }
    }
}
