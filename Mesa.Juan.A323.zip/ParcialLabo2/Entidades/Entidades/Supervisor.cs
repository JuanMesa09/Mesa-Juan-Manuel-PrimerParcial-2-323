﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Supervisor : Empleado
    {
        private static float valorHora = 1025.50f;

        public Supervisor(string legajo, string nombre, TimeSpan horaIngreso)
            : base(nombre, legajo, horaIngreso)
        {
        }


        public static float ValorHora
        {
            get => valorHora;
            set
            {
                if (value > 0)
                {
                    valorHora = value;
                }
            }
        }


        public float Facturar()
        {
            return (float)base.Facturar() * ValorHora;
        }

        public override string EmitirFactura()
        {
            return $"Factura de: {this}\nImporte a facturar: {Facturar()}";
        }


        public override string ToString()
        {
            return $"{GetType().Name} - {Legajo} - {Nombre}";
        }


        public static implicit operator Supervisor(string legajo)
        {
            return new Supervisor(legajo, "n/a", new TimeSpan(9, 0, 0));
        }
    }
}
