﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Empleado
    {
        protected string Nombre { get; }
        protected string Legajo { get; }
        protected TimeSpan HoraIngreso { get; }
        private TimeSpan horaEgreso;

        public TimeSpan HoraEgreso
        {
            get => horaEgreso;
            set => horaEgreso = ValidaHoraEgreso(value);
        }


        protected Empleado(string nombre, string legajo, TimeSpan horaIngreso)
        {
            Nombre = nombre;
            Legajo = legajo;
            HoraIngreso = horaIngreso;
        }


        private TimeSpan ValidaHoraEgreso(TimeSpan horaEgreso)
        {
            return horaEgreso > HoraIngreso ? horaEgreso : DateTime.Now.TimeOfDay;
        }


        public double Facturar()
        {
            return (HoraEgreso - HoraIngreso).TotalHours;
        }


        public override bool Equals(object obj)
        {
            if (obj is Empleado empleado)
            {
                return Legajo == empleado.Legajo;
            }
            return false;
        }


        public override int GetHashCode()
        {
            return Legajo.GetHashCode();
        }


        public static bool operator ==(Empleado e1, Empleado e2)
        {
            if (ReferenceEquals(e1, e2)) return true;
            if (e1 is null || e2 is null) return false;
            return e1.Legajo == e2.Legajo;
        }


        public static bool operator !=(Empleado e1, Empleado e2)
        {
            return !(e1 == e2);
        }


        public override string ToString()
        {
            return $"{GetType().Name} - {Legajo} - {Nombre}";
        }


        public abstract string EmitirFactura();
    }
}
