﻿using System.Text;

namespace Entidades
{
    public class CentroDeAtencion
    {
        private readonly List<Empleado> empleados;
        private readonly int cantRacsPorSuper;

        public CentroDeAtencion(string nombre, int cantRacsPorSuper)
        {
            empleados = new List<Empleado>();
            this.cantRacsPorSuper = cantRacsPorSuper;
        }


        private bool ValidaCantidadDeRacs()
        {
            int racCount = empleados.FindAll(e => e is Rac).Count;
            int supervisorCount = empleados.FindAll(e => e is Supervisor).Count;
            return racCount > supervisorCount * cantRacsPorSuper;
        }


        public static bool operator ==(CentroDeAtencion c, Empleado e)
        {
            return c.empleados.Contains(e);
        }


        public static bool operator !=(CentroDeAtencion c, Empleado e)
        {
            return !c.empleados.Contains(e);
        }


        public static bool operator +(CentroDeAtencion c, Empleado e)
        {
            if (c == e) return false;
            if (e is Supervisor && !c.ValidaCantidadDeRacs()) return false;
            c.empleados.Add(e);
            return true;
        }


        public static string operator -(CentroDeAtencion c, Empleado e)
        {
            if (c == e)
            {
                e.HoraEgreso = DateTime.Now.TimeOfDay;
                c.empleados.Remove(e);
                return e.EmitirFactura();
            }
            return "Empleado no encontrado";
        }


        public string ImprimirNomina()
        {
            var sb = new StringBuilder();
            foreach (var empleado in empleados)
            {
                sb.AppendLine(empleado.ToString());
            }
            return sb.ToString();
        }
    }
}
